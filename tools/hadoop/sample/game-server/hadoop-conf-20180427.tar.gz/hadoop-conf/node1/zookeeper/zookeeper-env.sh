export ZOO_LOG_DIR=/data/apache/zookeeper/logs
