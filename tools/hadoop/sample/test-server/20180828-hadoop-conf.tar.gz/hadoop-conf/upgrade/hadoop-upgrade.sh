# hadoop upgrade
old_ver=2.7.3
new_ver=2.8.3
tar -zxvf hadoop-${new_ver}.tar.gz
mv hadoop hadoop-${old_ver}
mv hadoop-${new_ver} hadoop
cp hadoop-${old_ver}/etc/hadoop/hadoop-env.sh hadoop/etc/hadoop/
cp hadoop-${old_ver}/etc/hadoop/yarn-env.sh hadoop/etc/hadoop/
cp hadoop-${old_ver}/etc/hadoop/core-site.xml hadoop/etc/hadoop/
cp hadoop-${old_ver}/etc/hadoop/hdfs-site.xml hadoop/etc/hadoop/
cp hadoop-${old_ver}/etc/hadoop/yarn-site.xml hadoop/etc/hadoop/
cp hadoop-${old_ver}/etc/hadoop/mapred-site.xml hadoop/etc/hadoop/
cp hadoop-${old_ver}/etc/hadoop/slaves hadoop/etc/hadoop/
