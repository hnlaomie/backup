# hive upgrade
old_ver=2.1.1
new_ver=2.3.2
tar -zxvf apache-hive-${new_ver}-bin.tar.gz
mv hive hive-${old_ver}
mv apache-hive-${new_ver}-bin hive 

cp hive-${old_ver}/conf/hive-env.sh hive/conf/
cp hive-${old_ver}/conf/hive-site.xml hive/conf/
cp hive-${old_ver}/conf/hive-log4j.properties hive/conf/
cp hive-${old_ver}/lib/mysql-connector-java-5.1.39.jar hive/lib/
