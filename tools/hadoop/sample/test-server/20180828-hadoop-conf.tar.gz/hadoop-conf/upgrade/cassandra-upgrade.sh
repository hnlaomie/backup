old_ver=3.0.7
new_ver=3.0.10

tar -zxvf apache-cassandra-${new_ver}-bin.tar.gz
mv cassandra cassandra-${old_ver}
mv apache-cassandra-${new_ver} cassandra
cp cassandra-${old_ver}/conf/cassandra-rackdc.properties cassandra/conf/
cp cassandra-${old_ver}/conf/cassandra-topology.properties cassandra/conf/
cp cassandra-${old_ver}/conf/logback.xml cassandra/conf/
