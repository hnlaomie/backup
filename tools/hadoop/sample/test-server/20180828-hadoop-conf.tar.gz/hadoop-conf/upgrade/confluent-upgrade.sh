confluent_old_ver=4.1.1
confluent_new_ver=4.1.2

tar -zxvf confluent-oss-${confluent_new_ver}-2.11.tar.gz
mv confluent confluent-${confluent_old_ver}
mv confluent-${confluent_new_ver} confluent

# zookeeper
mkdir -p confluent/etc/kafka/bak
mv confluent/etc/kafka/zookeeper.properties confluent/etc/kafka/bak/
cp confluent-${confluent_old_ver}/etc/kafka/zookeeper.properties confluent/etc/kafka/

# kafka
mv confluent/etc/kafka/server.properties confluent/etc/kafka/bak/
cp confluent-${confluent_old_ver}/etc/kafka/server.properties confluent/etc/kafka/

# schema-registry
mkdir -p confluent/etc/schema-registry/bak
mv confluent/etc/schema-registry/schema-registry.properties confluent/etc/schema-registry/bak/
cp confluent-${confluent_old_ver}/etc/schema-registry/schema-registry.properties confluent/etc/schema-registry/

# kafka-rest
mkdir -p confluent/etc/kafka-rest/bak
mv confluent/etc/kafka-rest/kafka-rest.properties confluent/etc/kafka-rest/bak/
cp confluent-${confluent_old_ver}/etc/kafka-rest/kafka-rest.properties confluent/etc/kafka-rest/

# connector
mv confluent/etc/kafka/connect-* confluent/etc/kafka/bak/
cp confluent/etc/kafka/bak/connect-log4j.properties confluent/etc/kafka/
cp confluent-${confluent_old_ver}/etc/kafka/connect-distributed.properties confluent/etc/kafka/

mv confluent/etc/schema-registry/connect-* confluent/etc/schema-registry/bak
cp confluent-${confluent_old_ver}/etc/schema-registry/connect-avro-distributed.properties confluent/etc/schema-registry/

mkdir -p confluent/etc/kafka-connect-hdfs/bak
mv confluent/etc/kafka-connect-hdfs/quickstart* confluent/etc/kafka-connect-hdfs/bak
cp confluent-${confluent_old_ver}/etc/kafka-connect-hdfs/dsp-hdfs.properties confluent/etc/kafka-connect-hdfs/

# delete unuse connector
tar -zcvf confluent/etc/camus.tar.gz confluent/etc/camus
tar -zcvf confluent/etc/kafka-connect-s3.tar.gz confluent/etc/kafka-connect-s3
rm -fr confluent/etc/camus
rm -fr confluent/etc/kafka-connect-s3

tar -zcvf confluent/share/java/camus.tar.gz confluent/share/java/camus
tar -zcvf confluent/share/java/kafka-connect-s3.tar.gz confluent/share/java/kafka-connect-s3
rm -fr confluent/share/java/camus
rm -fr confluent/share/java/kafka-connect-s3
