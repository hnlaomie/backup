# zookeeper upgrade
zk_old_ver=3.4.11
zk_new_ver=3.4.12
tar -zxvf zookeeper-${zk_new_ver}.tar.gz
mv zookeeper zookeeper-${zk_old_ver}
mv zookeeper-${zk_new_ver} zookeeper
mkdir zookeeper/logs
cp zookeeper-${zk_old_ver}/conf/zoo.cfg zookeeper/conf/
cp zookeeper-${zk_old_ver}/conf/zookeeper-env.sh zookeeper/conf/
