# hadoop upgrade
old_ver=2.2.0
new_ver=2.2.1
hadoop_ver=2.7.3

tar -zxvf spark-${new_ver}-bin-${hadoop_ver}.tgz
mv spark spark-${old_ver}
mv spark-${new_ver}-bin-${hadoop_ver} spark

rm -fr /data/hadoop/spark/data/*
rm -fr /data/hadoop/spark/pids/*
rm -fr /data/hadoop/spark/logs/*
rm -fr /data/hadoop/spark/worker/*
rm -fr /data/hadoop/spark/tmp/*

cp spark-${old_ver}/conf/spark-env.sh spark/conf/
cp spark-${old_ver}/conf/hive-site.xml spark/conf/
cp spark-${old_ver}/conf/log4j.properties spark/conf/
cp spark-${old_ver}/conf/slaves spark/conf/
cp spark-${old_ver}/conf/spark-defaults.conf spark/conf/
cp spark-${old_ver}/jars/mysql-connector-java-5.1.39.jar spark/jars/
