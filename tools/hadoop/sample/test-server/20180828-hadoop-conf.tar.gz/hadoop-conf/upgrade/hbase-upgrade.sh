# hadoop upgrade
old_ver=1.1.2
new_ver=1.2.6
tar -zxvf hbase-${new_ver}-bin.tar.gz
mv hbase hbase-${old_ver}
mv hbase-${new_ver} hbase
#cp hbase-${old_ver}/conf/hbase-env.sh hbase/conf/
cp hbase-${old_ver}/conf/hbase-site.xml hbase/conf/
#cp hbase-${old_ver}/conf/hdfs-site.xml hbase/conf/
cp hbase-${old_ver}/conf/regionservers hbase/conf/
