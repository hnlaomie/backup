#!/bin/bash

servers=('test-master' 'test-node1' 'test-node2')

for server in ${servers[@]};do
    mkdir -p ${server}/hadoop
    mkdir -p ${server}/hbase
    mkdir -p ${server}/hive
    mkdir -p ${server}/zookeeper
    mkdir -p ${server}/spark
    mkdir -p ${server}/kafka
    mkdir -p ${server}/cassandra
    mkdir -p ${server}/tez/conf
    mkdir -p ${server}/presto/etc/catalog
    mkdir -p ${server}/crontab

    # hadoop backup
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/hadoop-env.sh ${server}/hadoop/
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/yarn-env.sh ${server}/hadoop/
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/hdfs-site.xml ${server}/hadoop/
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/mapred-site.xml ${server}/hadoop/
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/core-site.xml ${server}/hadoop/
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/yarn-site.xml ${server}/hadoop/
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/slaves ${server}/hadoop/

    # hbase backup
    scp hadoop@${server}:/data/apache/hbase/conf/hbase-env.sh ${server}/hbase/
    scp hadoop@${server}:/data/apache/hbase/conf/hbase-site.xml ${server}/hbase/
    scp hadoop@${server}:/data/apache/hbase/conf/regionservers ${server}/hbase/

    # hive backup
    scp hadoop@${server}:/data/apache/hive/conf/hive-env.sh ${server}/hive/
    scp hadoop@${server}:/data/apache/hive/conf/hive-site.xml ${server}/hive/
    scp hadoop@${server}:/data/apache/hive/conf/hive-log4j.properties ${server}/hive/

    # zookeeper backup
    scp hadoop@${server}:/data/apache/zookeeper/conf/log4j.properties ${server}/zookeeper/
    scp hadoop@${server}:/data/apache/zookeeper/conf/zoo.cfg ${server}/zookeeper/
    scp hadoop@${server}:/data/apache/zookeeper/conf/zookeeper-env.sh ${server}/zookeeper/

    # spark backup
    scp hadoop@${server}:/data/apache/spark/conf/hive-site.xml ${server}/spark/
    scp hadoop@${server}:/data/apache/spark/conf/log4j.properties ${server}/spark/
    scp hadoop@${server}:/data/apache/spark/conf/spark-defaults.conf ${server}/spark/
    scp hadoop@${server}:/data/apache/spark/conf/slaves ${server}/spark/
    scp hadoop@${server}:/data/apache/spark/conf/spark-env.sh ${server}/spark/

    # kafka backup
    scp hadoop@${server}:/data/apache/kafka/config/server.properties ${server}/kafka/

    # cassandra backup
    scp hadoop@${server}:/data/apache/cassandra/conf/cassandra.yaml ${server}/cassandra/
    scp hadoop@${server}:/data/apache/cassandra/conf/cassandra-env.sh ${server}/cassandra/
    scp hadoop@${server}:/data/apache/cassandra/conf/cassandra-rackdc.properties ${server}/cassandra/
    scp hadoop@${server}:/data/apache/cassandra/conf/cassandra-topology.properties ${server}/cassandra/
    scp hadoop@${server}:/data/apache/cassandra/conf/logback.xml ${server}/cassandra/

    # presto backup
    scp hadoop@${server}:/data/apache/presto-server/etc/* ${server}/presto/etc/
    scp hadoop@${server}:/data/apache/presto-server/etc/catalog/* ${server}/presto/etc/catalog/

    # tez backup
    scp hadoop@${server}:/data/apache/tez/conf/* ${server}/tez/conf/

    # crontab
    scp hadoop@${server}:/var/spool/cron/root ${server}/crontab/
    scp hadoop@${server}:/var/spool/cron/hadoop ${server}/crontab/
done

