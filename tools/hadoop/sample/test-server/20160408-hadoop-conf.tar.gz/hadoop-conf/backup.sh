#!/bin/bash

servers=('test-master' 'test-node1' 'test-node2')

for server in ${servers[@]};do

    mkdir -p ${server}/hadoop
    mkdir -p ${server}/hbase
    mkdir -p ${server}/hive
    mkdir -p ${server}/zookeeper
    mkdir -p ${server}/spark
    mkdir -p ${server}/kafka
    mkdir -p ${server}/cassandra

    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/hadoop-env.sh ${server}/hadoop/
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/yarn-env.sh ${server}/hadoop/
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/hdfs-site.xml ${server}/hadoop/
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/mapred-site.xml ${server}/hadoop/
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/core-site.xml ${server}/hadoop/
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/yarn-site.xml ${server}/hadoop/
    scp hadoop@${server}:/data/apache/hadoop/etc/hadoop/slaves ${server}/hadoop/

    scp hadoop@${server}:/data/apache/hbase/conf/hbase-env.sh ${server}/hbase/
    scp hadoop@${server}:/data/apache/hbase/conf/hbase-site.xml ${server}/hbase/
    scp hadoop@${server}:/data/apache/hbase/conf/regionservers ${server}/hbase/

    scp hadoop@${server}:/data/apache/hive/conf/hive-env.sh ${server}/hive/
    scp hadoop@${server}:/data/apache/hive/conf/hive-site.xml ${server}/hive/
    scp hadoop@${server}:/data/apache/hive/conf/hive-log4j.properties ${server}/hive/

    scp hadoop@${server}:/data/apache/zookeeper/conf/log4j.properties ${server}/zookeeper/
    scp hadoop@${server}:/data/apache/zookeeper/conf/zoo.cfg ${server}/zookeeper/
    scp hadoop@${server}:/data/apache/zookeeper/conf/zookeeper-env.sh ${server}/zookeeper/

    scp hadoop@${server}:/data/apache/spark/conf/hive-site.xml ${server}/spark/
    scp hadoop@${server}:/data/apache/spark/conf/log4j.properties ${server}/spark/
    scp hadoop@${server}:/data/apache/spark/conf/spark-defaults.conf ${server}/spark/
    scp hadoop@${server}:/data/apache/spark/conf/slaves ${server}/spark/
    scp hadoop@${server}:/data/apache/spark/conf/spark-env.sh ${server}/spark/

    scp hadoop@${server}:/data/apache/kafka/config/server.properties ${server}/kafka/

    scp hadoop@${server}:/data/apache/cassandra/conf/cassandra.yaml ${server}/cassandra/
    scp hadoop@${server}:/data/apache/cassandra/conf/cassandra-env.sh ${server}/cassandra/
    scp hadoop@${server}:/data/apache/cassandra/conf/cassandra-rackdc.properties ${server}/cassandra/
    scp hadoop@${server}:/data/apache/cassandra/conf/cassandra-topology.properties ${server}/cassandra/
    scp hadoop@${server}:/data/apache/cassandra/conf/logback.xml ${server}/cassandra/

done

