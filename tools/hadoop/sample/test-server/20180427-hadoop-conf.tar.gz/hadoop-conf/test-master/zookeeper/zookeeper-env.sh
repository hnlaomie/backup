export ZOO_LOG_DIR=$ZK_HOME/logs
