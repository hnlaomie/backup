#!/bin/bash

servers=('master' 'node1' 'node2' 'node3' 'node4' 'node5' 'node6' 'node7' 'node8' 'node9' 'node10')

for server in ${servers[@]};do

    mkdir -p ${server}/hadoop
    mkdir -p ${server}/hbase
    mkdir -p ${server}/hive
    mkdir -p ${server}/zookeeper
    mkdir -p ${server}/spark
    mkdir -p ${server}/kafka
    mkdir -p ${server}/cassandra

    scp root@${server}:/usr/local/hadoop/etc/hadoop/hadoop-env.sh ${server}/hadoop/
    scp root@${server}:/usr/local/hadoop/etc/hadoop/yarn-env.sh ${server}/hadoop/
    scp root@${server}:/usr/local/hadoop/etc/hadoop/hdfs-site.xml ${server}/hadoop/
    scp root@${server}:/usr/local/hadoop/etc/hadoop/mapred-site.xml ${server}/hadoop/
    scp root@${server}:/usr/local/hadoop/etc/hadoop/core-site.xml ${server}/hadoop/
    scp root@${server}:/usr/local/hadoop/etc/hadoop/yarn-site.xml ${server}/hadoop/
    scp root@${server}:/usr/local/hadoop/etc/hadoop/slaves ${server}/hadoop/

    scp root@${server}:/usr/local/hbase/conf/hbase-env.sh ${server}/hbase/
    scp root@${server}:/usr/local/hbase/conf/hbase-site.xml ${server}/hbase/
    scp root@${server}:/usr/local/hbase/conf/regionservers ${server}/hbase/

    scp root@${server}:/usr/local/hive-1.2.1/conf/hive-env.sh ${server}/hive/
    scp root@${server}:/usr/local/hive-1.2.1/conf/hive-site.xml ${server}/hive/
    scp root@${server}:/usr/local/hive-1.2.1/conf/hive-log4j.properties ${server}/hive/

    scp root@${server}:/usr/local/zookeeper/conf/log4j.properties ${server}/zookeeper/
    scp root@${server}:/usr/local/zookeeper/conf/zoo.cfg ${server}/zookeeper/
    scp root@${server}:/usr/local/zookeeper/conf/zookeeper-env.sh ${server}/zookeeper/

    scp root@${server}:/usr/local/spark/conf/hive-site.xml ${server}/spark/
    scp root@${server}:/usr/local/spark/conf/log4j.properties ${server}/spark/
    scp root@${server}:/usr/local/spark/conf/slaves ${server}/spark/
    scp root@${server}:/usr/local/spark/conf/spark-env.sh ${server}/spark/
    scp root@${server}:/usr/local/spark/conf/spark-env.sh ${server}/spark/

    # kafka backup
    scp root@${server}:/usr/local/kafka/config/server.properties ${server}/kafka/

    # cassandra backup
    scp root@${server}:/usr/local/cassandra/conf/cassandra.yaml ${server}/cassandra/
    scp root@${server}:/usr/local/cassandra/conf/cassandra-env.sh ${server}/cassandra/
    scp root@${server}:/usr/local/cassandra/conf/cassandra-rackdc.properties ${server}/cassandra/
    scp root@${server}:/usr/local/cassandra/conf/cassandra-topology.properties ${server}/cassandra/
    scp root@${server}:/usr/local/cassandra/conf/logback.xml ${server}/cassandra/
done

