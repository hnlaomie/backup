#!/bin/bash

servers=('master' 'node1' 'node2' 'node8' 'node9' 'node10')

for server in ${servers[@]};do

    mkdir -p ${server}/hadoop
    mkdir -p ${server}/hbase
    mkdir -p ${server}/hive

    scp root@${server}:/usr/local/hadoop-2.2.0/etc/hadoop/hadoop-env.sh ${server}/hadoop/
    scp root@${server}:/usr/local/hadoop-2.2.0/etc/hadoop/hdfs-site.xml ${server}/hadoop/
    scp root@${server}:/usr/local/hadoop-2.2.0/etc/hadoop/mapred-site.xml ${server}/hadoop/
    scp root@${server}:/usr/local/hadoop-2.2.0/etc/hadoop/core-site.xml ${server}/hadoop/
    scp root@${server}:/usr/local/hadoop-2.2.0/etc/hadoop/yarn-site.xml ${server}/hadoop/
    scp root@${server}:/usr/local/hadoop-2.2.0/etc/hadoop/slaves ${server}/hadoop/

    scp root@${server}:/usr/local/hbase-0.96.2/conf/hbase-env.sh ${server}/hbase/
    scp root@${server}:/usr/local/hbase-0.96.2/conf/hbase-site.xml ${server}/hbase/
    scp root@${server}:/usr/local/hbase-0.96.2/conf/regionservers ${server}/hbase/

    scp root@${server}:/usr/local/hive-0.13.0/conf/hive-env.sh ${server}/hive/
    scp root@${server}:/usr/local/hive-0.13.0/conf/hive-site.xml ${server}/hive/
    scp root@${server}:/usr/local/hive-0.13.0/conf/hive-log4j.properties ${server}/hive/

done

