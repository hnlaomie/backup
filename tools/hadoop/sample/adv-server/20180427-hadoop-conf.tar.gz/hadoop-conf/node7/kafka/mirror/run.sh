$KAFKA_HOME/bin/kafka-mirror-maker.sh --consumer.config etc/consumer.properties --producer.config etc/producer.properties --num.streams=2 --whitelist 'dsp\w*'
